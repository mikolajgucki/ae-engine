Flurry iOS SDK 5.3
============================

Flurry SDK 5.3 is compatible with  Xcode 5 and will support your app on iOS8 and prior iOS versions. 

If you are developing with Xcode 6 please use Flurry SDK 5.4 available for download from https://dev.flurry.com