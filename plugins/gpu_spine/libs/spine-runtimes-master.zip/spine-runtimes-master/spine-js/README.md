# spine-js

spine-js has been deprecated and is superseded by [spine-ts](https://github.com/EsotericSoftware/spine-runtimes/tree/master/spine-ts). The most recent version of spine-js can be found in the [spine-js branch](https://github.com/EsotericSoftware/spine-runtimes/tree/spine-js/spine-js)
