TapjoyEasyApp is a simple sample project that exhibits best-in-class virtual currency, ads, and events implementation.

For more information and product documentation, please go to http://dev.tapjoy.com 