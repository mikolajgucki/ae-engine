#ifndef __MAIN_H__
#define __MAIN_H__

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <tchar.h>

#endif    // __MAIN_H__
