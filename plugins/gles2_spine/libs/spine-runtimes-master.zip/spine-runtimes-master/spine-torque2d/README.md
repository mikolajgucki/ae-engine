# spine-torque2d

The Spine runtime for [Torque2D](https://www.garagegames.com/products/torque-2d) is currently integrated into Torque2D itself:

https://github.com/GarageGames/Torque2D/tree/spine

Unfortunately, it is also a bit out of date. An updated Torque2D Spine runtime is planned.
