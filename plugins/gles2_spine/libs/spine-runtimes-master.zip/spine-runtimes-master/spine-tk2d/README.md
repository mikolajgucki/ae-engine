# spine-tk2d

The spine-tk2d runtime has been merged into [spine-unity](https://github.com/EsotericSoftware/spine-runtimes/tree/master/spine-unity). You may use spine-unity with [2D Toolkit](http://www.unikronsoftware.com/2dtoolkit/).
